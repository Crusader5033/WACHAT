const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const sql = require('mssql');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

app.use(cors());
app.use(bodyParser.json());

const config = {
  server: '193.85.203.188',
  database: 'prochazka6',
  user: 'prochazka6',
  password: 'dominik2005',
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};

const rooms = [];

const messages = [];

const users = {};

app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;

  try {
    const pool = await sql.connect(config);

    const checkQuery = `SELECT * FROM users WHERE username = '${username}'`;
    const checkResult = await pool.request().query(checkQuery);

    if (checkResult.recordset.length > 0) {
      res.status(400).json({ error: 'User already exists' });
    } else {
      const insertQuery = `INSERT INTO users (username, password) VALUES ('${username}', '${password}')`;
      await pool.request().query(insertQuery);

      res.sendStatus(200);
    }
  } catch (error) {
    console.error(error);
    res.sendStatus(500);
  }
});


app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const pool = await sql.connect(config);

    const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
    const result = await pool.request().query(query);

    if (result.recordset.length > 0) {
      res.sendStatus(200);
    } else {
      res.sendStatus(401);
    }
  } catch (error) {
    console.error(error);
    res.sendStatus(500);
  }
});

io.on('connection', (socket) => {
  console.log('User connected');

  socket.on('setUsername', (username) => {
    users[socket.id] = username;
  });

  socket.emit('initialMessages', messages);

  socket.on('sendMessage', (data) => {
    const username = users[socket.id] || 'Anonymous';
    const messageData = { user: username, message: data.message };

    messages.push(messageData);

    io.emit('message', messageData);
  });

  /*socket.on('joinRoom', (data) => {
    const { roomName, isPrivate } = data;

    // Emit previous messages for the specific room to the user
    const roomMessages = messages.filter((msg) => msg.room === roomName);
    socket.emit('initialMessages', roomMessages);

    // Check if the room already exists
    const existingRoom = rooms.find((room) => room.name === roomName);

    if (existingRoom) {
      // Room already exists, update the room details if necessary
      existingRoom.isPrivate = isPrivate; // Update room privacy status
    } else {
      // Room doesn't exist, create a new room
      const newRoom = { name: roomName, isPrivate };
      rooms.push(newRoom);

      // Broadcast the updated list of rooms to all clients
      io.emit('updateRoomsList', rooms);
    }

    // Logic for joining the room
    // (This can involve adding the user to the list of room participants, handling room-specific events, etc.)
  });*/

 /* socket.on('createRoom', (data) => {
    const { roomName, isPrivate } = data;

    // Create a new room
    const newRoom = { name: roomName, isPrivate };
    rooms.push(newRoom);

    // Broadcast the updated list of rooms to all clients
    io.emit('updateRoomsList', rooms);
  });*/

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

app.use(express.static(__dirname));

server.listen(3000, () => {
  console.log('Server is running on port 3000');
});
